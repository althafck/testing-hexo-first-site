module.exports = function (grunt) {
    
    grunt.initConfig({
        critical: {
            dist: {
              options: {
                base: '/',
                inline: true,
                css: [
                  'public/bootstrap/*.css',
                  'public/css/*.css'
                ],
                dimensions: [{
                  width: 1300,
                  height: 900
                },
                {
                  width: 500,
                  height: 900
                }],
                extract: true
              },
              src: 'public/*.html',
              dest:  'public/dist/'
            }
          }
      });
    
      // Load the plugins
      grunt.loadNpmTasks('grunt-critical');
    
      // Default tasks.
      grunt.registerTask('default', ['critical']);
    };