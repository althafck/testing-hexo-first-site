---
layout: products-main
title: foobar
date: 2017-11-12 18:06:27
---

this is a foobar layout